import { combineReducers } from "redux";

import chestsReducer from "./chestsReducer";

export default combineReducers({
  chests: chestsReducer,
});

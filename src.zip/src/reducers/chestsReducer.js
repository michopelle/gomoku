let chests = [];
for (let i = 0; i < 15; i++) {
  chests[i] = [];
  for (let j = 0; j < 15; j++) {
    chests[i][j] = "blank";
  }
}

export default (state = chests, action) => {
  switch (action.type) {
    case "CHEST_MOVE":
      return state.map((el) =>
        el === action.payload[0]
          ? el.map((ele) => (ele === action.payload[1] ? action.side : ele))
          : el
      );

    //   state.map(el => el === action.payload[0] ? {...action.payload[0], [action.payload[0].payload[1]]: action.side } : el)
    // ...state,
    // [action.payload[0]]: {
    //   ...action.payload[0],
    //   [action.payload[0].payload[1]]: action.side,
    // },
    default:
      return state;
  }
};

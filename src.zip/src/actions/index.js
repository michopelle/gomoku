export const chestMove = (position, side) => {
  return {
    type: "CHEST_MOVE",
    payload: position,
    side: side,
  };
};

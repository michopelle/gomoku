import React from "react";

import Board from "./Board";

const App = () => {
  return <Board />;
};

export default App;

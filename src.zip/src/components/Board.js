import React from "react";
import { connect } from "react-redux";

import { chestMove } from "../actions";

class Board extends React.Component {
  renderedList() {
    console.log(this.props.chests);
    return this.props.chests.map((chestList) => {
      return (
        <div>
          {chestList.map((chest, index) => {
            return (
              <div onClick={() => this.props.chestMove("00", "white")}>
                {index}
                {chest}
              </div>
            );
          })}
        </div>
      );
    });
  }

  render() {
    return <div>{this.renderedList()}</div>;
  }
}

const mapStateToProps = (state) => {
  return {
    chests: state.chests,
  };
};

export default connect(mapStateToProps, { chestMove })(Board);
